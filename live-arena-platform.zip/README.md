# Live Arena — starter

A mobile-friendly browser game + Node.js server + Socket.IO + optional TikTok LIVE event connector.

## Requirements
- Node.js 20 or newer
- A TikTok LIVE account that is currently live and publicly accessible for the connector to test against
- Note: `tiktok-live-connector` is an unofficial third-party integration. It can break when TikTok changes its systems and is not an official TikTok API.

## Run locally
1. Install Node.js.
2. Copy `.env.example` to `.env`.
3. Run `npm install`.
4. Run `npm start`.
5. Open `http://localhost:3000`.

## Run from a phone
You can edit files in GitHub's web editor, then deploy this repository to a Node.js host such as Render. This project needs a persistent Node.js web service; static-only hosting is not enough for the Socket.IO server.

## Deploy on Render
1. Push the project to a GitHub repository.
2. Create a **Web Service** on Render and connect the repository.
3. Build command: `npm install`
4. Start command: `npm start`
5. Add environment variables:
   - `TIKTOK_ENABLE=false` initially
   - `TIKTOK_USERNAME=your_username` only when ready to test a real live
6. Deploy. Use the HTTPS URL Render gives you.

Do not set `TIKTOK_ENABLE=true` until you are ready to test. The TikTok connector is unofficial and may stop working. Never publish cookies, session IDs, passwords, or `.env` values.

## Test mode
With `TIKTOK_ENABLE=false`, click **Send demo event** on the page. This generates local demo events only; they are not real TikTok events.

## Real TikTok events
1. Set `TIKTOK_ENABLE=true`.
2. Set `TIKTOK_USERNAME` to the live creator's username without `@`.
3. Restart/redeploy the service.
4. Start a public LIVE and check the server logs and connection indicator.

If the connector API changes, consult its current documentation: https://github.com/zerodytrash/TikTok-Live-Connector

## Current features
- Canvas arena with moving player tokens
- Start, pause and reset controls
- Live event feed and leaderboard
- Demo chat/gift/like/follow events
- Optional server-side TikTok connector
- Basic rate limiting for event effects

## Limitations
This is a starter MVP, not a finished commercial SaaS. It does not yet include user accounts, payments, persistent leaderboards, multi-tenant creator rooms, or official TikTok API approval. The real connector has not been verified against your account or a live session from this environment.
