const socket = io();
const canvas = document.getElementById("arena");
const ctx = canvas.getContext("2d");
const $ = (id) => document.getElementById(id);
let state = { running: true, score: 0, events: 0 };
let connector = { connected: false, mode: "demo" };
let feed = [];
const players = new Map();
const colors = ["#a78bfa", "#67e8f9", "#f9a8d4", "#86efac", "#fcd34d", "#fdba74", "#c4b5fd", "#fda4af"];
const icons = { gift: "🎁", chat: "💬", like: "❤️", follow: "➕" };
const arenaPlayers = [];

function getPlayer(name) {
  if (!players.has(name)) players.set(name, { name, score: 0, events: 0, color: colors[players.size % colors.length] });
  return players.get(name);
}
function addEvent(event) {
  feed.unshift(event);
  feed = feed.slice(0, 12);
  const player = getPlayer(event.username);
  player.events++;
  if (event.kind === "gift") player.score += Math.max(1, event.points || 10);
  if (event.kind === "like") player.score += 1;
  if (!arenaPlayers.some(p => p.name === event.username)) {
    arenaPlayers.push({ name: event.username, x: 90 + Math.random() * (canvas.width - 180), y: 90 + Math.random() * (canvas.height - 180), r: 18, color: player.color, angle: Math.random() * 6.28, targetX: 0, targetY: 0 });
  }
  const p = arenaPlayers.find(p => p.name === event.username);
  if (p) { p.targetX = 40 + Math.random() * (canvas.width - 80); p.targetY = 50 + Math.random() * (canvas.height - 100); p.angle += 1.5; }
  renderFeed(); renderLeaderboard();
}
function renderFeed() {
  $("feedCount").textContent = feed.length;
  $("eventFeed").innerHTML = feed.length ? feed.map(e => `<div class="event-item"><div class="event-icon">${icons[e.kind] || "⚡"}</div><div class="event-copy"><b>${escapeHtml(e.username)}</b> ${escapeHtml(e.message || "")}<span class="event-time">${new Date(e.at || Date.now()).toLocaleTimeString("pt-BR",{hour:"2-digit",minute:"2-digit",second:"2-digit"})}</span></div></div>`).join("") : '<div class="empty">Aguardando eventos...</div>';
}
function renderLeaderboard() {
  const top = [...players.values()].sort((a,b) => b.score - a.score || b.events - a.events).slice(0,8);
  $("playerCount").textContent = players.size;
  $("leaderboard").innerHTML = top.length ? top.map((p,i) => `<div class="leader-row"><div class="rank">${i+1}</div><div><span class="player-name">${escapeHtml(p.name)}</span><span class="player-sub">${p.events} evento(s)</span></div><div class="player-score">${p.score} pts</div></div>`).join("") : '<div class="empty">Os participantes aparecerão aqui quando houver eventos.</div>';
}
function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, ch => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;" }[ch]));
}
function resizeCanvas() {
  const ratio = Math.max(1, Math.min(2, window.devicePixelRatio || 1));
  const rect = canvas.getBoundingClientRect();
  canvas.width = Math.round(rect.width * ratio);
  canvas.height = Math.round(rect.width * (520/960) * ratio);
  ctx.setTransform(canvas.width / 960, 0, 0, canvas.width / 960, 0, 0);
}
function drawArena() {
  const w = 960, h = 520;
  ctx.clearRect(0,0,w,h);
  const bg = ctx.createLinearGradient(0,0,w,h); bg.addColorStop(0,"#15182a"); bg.addColorStop(1,"#101321"); ctx.fillStyle=bg; ctx.fillRect(0,0,w,h);
  ctx.strokeStyle="rgba(139,92,246,.10)"; ctx.lineWidth=1;
  for(let x=0;x<w;x+=40){ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,h);ctx.stroke();}
  for(let y=0;y<h;y+=40){ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(w,y);ctx.stroke();}
  ctx.strokeStyle="rgba(103,232,249,.35)";ctx.lineWidth=2;ctx.setLineDash([8,10]);ctx.beginPath();ctx.roundRect(18,18,w-36,h-36,20);ctx.stroke();ctx.setLineDash([]);
  ctx.fillStyle="rgba(139,92,246,.08)";ctx.beginPath();ctx.arc(w/2,h/2,95,0,Math.PI*2);ctx.fill();ctx.strokeStyle="rgba(167,139,250,.28)";ctx.beginPath();ctx.arc(w/2,h/2,95,0,Math.PI*2);ctx.stroke();
  ctx.textAlign="center";ctx.font="800 12px Inter, sans-serif";ctx.fillStyle="rgba(203,213,255,.35)";ctx.fillText(state.running ? "ARENA ATIVA" : "PARTIDA PAUSADA",w/2,h/2+4);
  arenaPlayers.forEach((p,i)=>{
    if(state.running && p.targetX){p.x += (p.targetX-p.x)*.018;p.y += (p.targetY-p.y)*.018;}
    ctx.save();ctx.translate(p.x,p.y);
    ctx.shadowBlur=22;ctx.shadowColor=p.color;ctx.fillStyle=p.color;ctx.beginPath();ctx.arc(0,0,p.r,0,Math.PI*2);ctx.fill();ctx.shadowBlur=0;
    ctx.fillStyle="#11121b";ctx.beginPath();ctx.arc(-6,-3,2.5,0,Math.PI*2);ctx.arc(6,-3,2.5,0,Math.PI*2);ctx.fill();
    ctx.strokeStyle="#11121b";ctx.lineWidth=2;ctx.beginPath();ctx.arc(0,3,6,.15,Math.PI-.15);ctx.stroke();
    ctx.restore();
    ctx.fillStyle="#f4f4ff";ctx.font="600 11px Inter,sans-serif";ctx.textAlign="center";ctx.fillText(p.name.slice(0,16),p.x,p.y+34);
    ctx.fillStyle="rgba(255,255,255,.13)";ctx.fillRect(p.x-20,p.y+40,40,4);ctx.fillStyle=p.color;ctx.fillRect(p.x-20,p.y+40,Math.min(40,12+(players.get(p.name)?.score||0)%29),4);
  });
  if(!arenaPlayers.length){ctx.textAlign="center";ctx.fillStyle="#777d9a";ctx.font="600 15px Inter,sans-serif";ctx.fillText("AGUARDANDO OS PRIMEIROS ESPECTADORES",w/2,h/2+145);ctx.font="12px Inter,sans-serif";ctx.fillStyle="#555b76";ctx.fillText("Use o botão de evento de teste para experimentar",w/2,h/2+168);}
  $("score").textContent=state.score; $("eventCount").textContent=state.events;
  $("gameStatus").textContent=state.running?"● PARTIDA EM ANDAMENTO":"Ⅱ PARTIDA PAUSADA";
  $("gameStatus").style.color=state.running?"#4de4d0":"#fbbf24";
  requestAnimationFrame(drawArena);
}
socket.on("connect", () => { $("connectionText").textContent="Servidor conectado"; $("connection").classList.add("connected"); });
socket.on("disconnect", () => { $("connectionText").textContent="Servidor desconectado"; $("connection").classList.remove("connected"); $("connection").classList.add("error"); });
socket.on("connector:status", (data) => {
  connector = data;
  if(data.connected && data.mode==="live"){ $("connectionText").textContent="TikTok LIVE conectado"; $("connection").classList.add("connected"); $("connection").classList.remove("error"); }
  else if(data.mode==="live"){ $("connectionText").textContent="TikTok LIVE desconectado"; $("connection").classList.remove("connected"); $("connection").classList.add("error"); }
  else { $("connectionText").textContent="Modo de demonstração"; $("connection").classList.remove("error"); }
});
socket.on("game:state", (next) => { state = next; });
socket.on("live:event", addEvent);
$("startBtn").onclick=()=>socket.emit("admin:control","start");
$("pauseBtn").onclick=()=>socket.emit("admin:control","pause");
$("resetBtn").onclick=()=>{ if(confirm("Reiniciar a partida e limpar o placar?")){players.clear();arenaPlayers.length=0;feed=[];renderFeed();renderLeaderboard();socket.emit("admin:control","reset");} };
$("demoBtn").onclick=()=>socket.emit("demo:event",{username:$("demoName").value || "Teste",kind:$("demoKind").value});
window.addEventListener("resize",resizeCanvas);
resizeCanvas();renderFeed();renderLeaderboard();drawArena();
