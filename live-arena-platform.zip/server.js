require("dotenv").config();

const express = require("express");
const http = require("http");
const path = require("path");
const { Server } = require("socket.io");

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: true, methods: ["GET", "POST"] }
});

const PORT = Number(process.env.PORT || 3000);
const PUBLIC_DIR = path.join(__dirname, "public");
app.use(express.static(PUBLIC_DIR));
app.get("/health", (_req, res) => res.json({ ok: true, service: "live-arena" }));

let gameState = { running: true, score: 0, events: 0 };
const recentEventIds = new Set();
let lastEffectAt = 0;

function safeName(value, fallback = "Espectador") {
  const name = String(value || fallback).replace(/[<>]/g, "").trim().slice(0, 28);
  return name || fallback;
}

function broadcastEvent(event) {
  const now = Date.now();
  // Avoid event floods making the game unplayable.
  if (now - lastEffectAt < 80 && event.kind !== "chat") return;
  lastEffectAt = now;
  gameState.events += 1;
  if (event.kind === "gift") gameState.score += Math.max(1, Math.min(Number(event.points) || 1, 100));
  if (event.kind === "like") gameState.score += 1;
  io.emit("live:event", {
    id: `${now}-${Math.random().toString(36).slice(2, 8)}`,
    username: safeName(event.username),
    kind: event.kind || "chat",
    message: String(event.message || "").slice(0, 120),
    points: Number(event.points) || 0,
    at: now
  });
  io.emit("game:state", gameState);
}

io.on("connection", (socket) => {
  socket.emit("game:state", gameState);
  socket.emit("connector:status", { connected: Boolean(global.tiktokConnected), mode: process.env.TIKTOK_ENABLE === "true" ? "live" : "demo" });

  socket.on("admin:control", (action) => {
    if (action === "start") gameState.running = true;
    if (action === "pause") gameState.running = false;
    if (action === "reset") gameState = { running: true, score: 0, events: 0 };
    io.emit("game:state", gameState);
  });

  socket.on("demo:event", (payload) => {
    if (process.env.NODE_ENV === "production" && process.env.ALLOW_DEMO_EVENTS === "false") return;
    const kind = ["gift", "chat", "like", "follow"].includes(payload?.kind) ? payload.kind : "gift";
    broadcastEvent({
      username: safeName(payload?.username, "Teste"),
      kind,
      message: payload?.message || (kind === "gift" ? "enviou uma Rosa 🌹" : "evento de demonstração"),
      points: kind === "gift" ? 10 : kind === "like" ? 1 : 0
    });
  });
});

async function startTikTokConnector() {
  if (process.env.TIKTOK_ENABLE !== "true") {
    console.log("TikTok connector disabled. Demo mode is active.");
    return;
  }

  const username = String(process.env.TIKTOK_USERNAME || "").replace(/^@/, "").trim();
  if (!username) {
    console.error("TIKTOK_ENABLE=true, but TIKTOK_USERNAME is empty.");
    return;
  }

  try {
    const connectorModule = require("tiktok-live-connector");
    const TikTokLiveConnection = connectorModule.TikTokLiveConnection;
    const WebcastEvent = connectorModule.WebcastEvent || {};
    if (!TikTokLiveConnection) throw new Error("TikTokLiveConnection export was not found. Check the installed connector version.");

    const connection = new TikTokLiveConnection(username);
    global.tiktokConnected = false;

    connection.on("connected", () => {
      global.tiktokConnected = true;
      console.log(`Connected to @${username}'s LIVE.`);
      io.emit("connector:status", { connected: true, mode: "live", username });
    });
    connection.on("disconnected", () => {
      global.tiktokConnected = false;
      console.log("TikTok LIVE connector disconnected.");
      io.emit("connector:status", { connected: false, mode: "live", username });
    });
    connection.on(WebcastEvent.CHAT || "chat", (data) => {
      broadcastEvent({
        kind: "chat",
        username: data?.uniqueId || data?.nickname || "Espectador",
        message: data?.comment || "comentou na live"
      });
    });
    connection.on(WebcastEvent.GIFT || "gift", (data) => {
      const giftName = data?.giftName || data?.giftDetails?.giftName || "presente";
      const count = Number(data?.repeatCount || 1);
      const streaking = Boolean(data?.gift?.repeatable) && !data?.repeatEnd;
      if (streaking) return;
      const giftId = `${data?.userId || data?.uniqueId || "user"}-${data?.giftId || giftName}-${data?.repeatCount || 1}-${Date.now()}`;
      if (recentEventIds.has(giftId)) return;
      recentEventIds.add(giftId);
      if (recentEventIds.size > 1000) recentEventIds.clear();
      broadcastEvent({
        kind: "gift",
        username: data?.uniqueId || data?.nickname || "Espectador",
        message: `enviou ${count > 1 ? `${count}x ` : ""}${giftName}`,
        points: Math.min(Math.max(count, 1), 100)
      });
    });
    connection.on(WebcastEvent.LIKE || "like", (data) => {
      broadcastEvent({
        kind: "like",
        username: data?.uniqueId || data?.nickname || "Espectador",
        message: "curtiu a live",
        points: 1
      });
    });
    connection.on(WebcastEvent.FOLLOW || "follow", (data) => {
      broadcastEvent({
        kind: "follow",
        username: data?.uniqueId || data?.nickname || "Espectador",
        message: "começou a seguir"
      });
    });

    const result = await connection.connect();
    console.log("TikTok connector connect() returned:", result ? "success" : "no result");
  } catch (error) {
    global.tiktokConnected = false;
    console.error("Could not connect to TikTok LIVE:", error.message);
    io.emit("connector:status", { connected: false, mode: "live", error: error.message });
  }
}

server.listen(PORT, async () => {
  console.log(`Live Arena running on port ${PORT}`);
  await startTikTokConnector();
});
